const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 3000;
const HTML = path.join(__dirname, "semkadrop_online_live.html");
const online = new Map();
const TTL = 25000;

function cleanup(){
  const now = Date.now();
  for (const [id, t] of online) if (now - t > TTL) online.delete(id);
}
setInterval(cleanup, 5000);

function body(req){
  return new Promise(resolve=>{
    let b="";
    req.on("data",c=>b+=c);
    req.on("end",()=>{try{resolve(JSON.parse(b||"{}"))}catch(e){resolve({})}});
  });
}
function json(res, obj){
  res.writeHead(200, {"Content-Type":"application/json; charset=utf-8",
                       "Cache-Control":"no-store"});
  res.end(JSON.stringify(obj));
}
http.createServer(async (req,res)=>{
  if(req.method==="GET" && (req.url==="/" || req.url==="/index.html")){
    res.writeHead(200, {"Content-Type":"text/html; charset=utf-8",
                         "Cache-Control":"no-store"});
    fs.createReadStream(HTML).pipe(res); return;
  }
  if(req.method==="POST" && req.url==="/api/online"){
    const x=await body(req);
    if(x.sessionId) online.set(String(x.sessionId), Date.now());
    cleanup();
    json(res,{online:online.size}); return;
  }
  if(req.method==="POST" && req.url==="/api/offline"){
    const x=await body(req);
    if(x.sessionId) online.delete(String(x.sessionId));
    cleanup();
    json(res,{online:online.size}); return;
  }
  res.writeHead(404); res.end("Not found");
}).listen(PORT,"0.0.0.0",()=>console.log("SEMKA DROP online server on port "+PORT));
